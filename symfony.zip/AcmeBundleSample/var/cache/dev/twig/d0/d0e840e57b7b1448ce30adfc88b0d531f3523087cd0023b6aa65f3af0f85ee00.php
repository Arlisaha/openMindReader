<?php

/* @WebProfiler/Collector/router.html.twig */
class __TwigTemplate_4d72774a3ba1bc897b36351ae14a4714eec718f4eb070387d7219ba4b69247e0 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("@WebProfiler/Profiler/layout.html.twig", "@WebProfiler/Collector/router.html.twig", 1);
        $this->blocks = array(
            'toolbar' => array($this, 'block_toolbar'),
            'menu' => array($this, 'block_menu'),
            'panel' => array($this, 'block_panel'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "@WebProfiler/Profiler/layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_33baf69563c6a037529760ff9649808ceea287ecf436ec4528b87fc3f26ea0f1 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_33baf69563c6a037529760ff9649808ceea287ecf436ec4528b87fc3f26ea0f1->enter($__internal_33baf69563c6a037529760ff9649808ceea287ecf436ec4528b87fc3f26ea0f1_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@WebProfiler/Collector/router.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_33baf69563c6a037529760ff9649808ceea287ecf436ec4528b87fc3f26ea0f1->leave($__internal_33baf69563c6a037529760ff9649808ceea287ecf436ec4528b87fc3f26ea0f1_prof);

    }

    // line 3
    public function block_toolbar($context, array $blocks = array())
    {
        $__internal_ef68b8ad488ec30483b00eadf31f72b5f7c1a537c8eb24cf5b275f34fdc6a0b4 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_ef68b8ad488ec30483b00eadf31f72b5f7c1a537c8eb24cf5b275f34fdc6a0b4->enter($__internal_ef68b8ad488ec30483b00eadf31f72b5f7c1a537c8eb24cf5b275f34fdc6a0b4_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "toolbar"));

        
        $__internal_ef68b8ad488ec30483b00eadf31f72b5f7c1a537c8eb24cf5b275f34fdc6a0b4->leave($__internal_ef68b8ad488ec30483b00eadf31f72b5f7c1a537c8eb24cf5b275f34fdc6a0b4_prof);

    }

    // line 5
    public function block_menu($context, array $blocks = array())
    {
        $__internal_9c25e013de4f47da0e9f9fe87d35004ae62cc635484355a874ba4aaecefa0105 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_9c25e013de4f47da0e9f9fe87d35004ae62cc635484355a874ba4aaecefa0105->enter($__internal_9c25e013de4f47da0e9f9fe87d35004ae62cc635484355a874ba4aaecefa0105_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "menu"));

        // line 6
        echo "<span class=\"label\">
    <span class=\"icon\">";
        // line 7
        echo twig_include($this->env, $context, "@WebProfiler/Icon/router.svg");
        echo "</span>
    <strong>Routing</strong>
</span>
";
        
        $__internal_9c25e013de4f47da0e9f9fe87d35004ae62cc635484355a874ba4aaecefa0105->leave($__internal_9c25e013de4f47da0e9f9fe87d35004ae62cc635484355a874ba4aaecefa0105_prof);

    }

    // line 12
    public function block_panel($context, array $blocks = array())
    {
        $__internal_45c3c8bc87bc456ee0eeb4d48960b1af98fd03341c6bf08aca8a0ba74b96b175 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_45c3c8bc87bc456ee0eeb4d48960b1af98fd03341c6bf08aca8a0ba74b96b175->enter($__internal_45c3c8bc87bc456ee0eeb4d48960b1af98fd03341c6bf08aca8a0ba74b96b175_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "panel"));

        // line 13
        echo "    ";
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\HttpKernelExtension')->renderFragment($this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("_profiler_router", array("token" => (isset($context["token"]) ? $context["token"] : $this->getContext($context, "token")))));
        echo "
";
        
        $__internal_45c3c8bc87bc456ee0eeb4d48960b1af98fd03341c6bf08aca8a0ba74b96b175->leave($__internal_45c3c8bc87bc456ee0eeb4d48960b1af98fd03341c6bf08aca8a0ba74b96b175_prof);

    }

    public function getTemplateName()
    {
        return "@WebProfiler/Collector/router.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  73 => 13,  67 => 12,  56 => 7,  53 => 6,  47 => 5,  36 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends '@WebProfiler/Profiler/layout.html.twig' %}

{% block toolbar %}{% endblock %}

{% block menu %}
<span class=\"label\">
    <span class=\"icon\">{{ include('@WebProfiler/Icon/router.svg') }}</span>
    <strong>Routing</strong>
</span>
{% endblock %}

{% block panel %}
    {{ render(path('_profiler_router', { token: token })) }}
{% endblock %}
", "@WebProfiler/Collector/router.html.twig", "/var/www/html/openMindReader/vendor/symfony/symfony/src/Symfony/Bundle/WebProfilerBundle/Resources/views/Collector/router.html.twig");
    }
}
