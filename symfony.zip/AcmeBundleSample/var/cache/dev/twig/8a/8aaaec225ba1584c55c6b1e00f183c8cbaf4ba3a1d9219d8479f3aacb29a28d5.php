<?php

/* @Twig/Exception/exception_full.html.twig */
class __TwigTemplate_604071950c5f79883a32b9f78b2b779a3013eb8265630790e167a832da6c1998 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("@Twig/layout.html.twig", "@Twig/Exception/exception_full.html.twig", 1);
        $this->blocks = array(
            'head' => array($this, 'block_head'),
            'title' => array($this, 'block_title'),
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "@Twig/layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_f0320638fc9cdd118930b1a561cfa1f8fbe9a738791cb1943b413d405c349819 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_f0320638fc9cdd118930b1a561cfa1f8fbe9a738791cb1943b413d405c349819->enter($__internal_f0320638fc9cdd118930b1a561cfa1f8fbe9a738791cb1943b413d405c349819_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Twig/Exception/exception_full.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_f0320638fc9cdd118930b1a561cfa1f8fbe9a738791cb1943b413d405c349819->leave($__internal_f0320638fc9cdd118930b1a561cfa1f8fbe9a738791cb1943b413d405c349819_prof);

    }

    // line 3
    public function block_head($context, array $blocks = array())
    {
        $__internal_c889347868ff7dece0b69fbc65c299bcdda7daa8f0271122e5ee26d5dd90ede9 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_c889347868ff7dece0b69fbc65c299bcdda7daa8f0271122e5ee26d5dd90ede9->enter($__internal_c889347868ff7dece0b69fbc65c299bcdda7daa8f0271122e5ee26d5dd90ede9_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "head"));

        // line 4
        echo "    <link href=\"";
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\HttpFoundationExtension')->generateAbsoluteUrl($this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("bundles/framework/css/exception.css")), "html", null, true);
        echo "\" rel=\"stylesheet\" type=\"text/css\" media=\"all\" />
";
        
        $__internal_c889347868ff7dece0b69fbc65c299bcdda7daa8f0271122e5ee26d5dd90ede9->leave($__internal_c889347868ff7dece0b69fbc65c299bcdda7daa8f0271122e5ee26d5dd90ede9_prof);

    }

    // line 7
    public function block_title($context, array $blocks = array())
    {
        $__internal_c6b076fcf2fdbb67606871676ac36c06d5c272dacaa3acddfacea66aa1e45dda = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_c6b076fcf2fdbb67606871676ac36c06d5c272dacaa3acddfacea66aa1e45dda->enter($__internal_c6b076fcf2fdbb67606871676ac36c06d5c272dacaa3acddfacea66aa1e45dda_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        // line 8
        echo "    ";
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["exception"]) ? $context["exception"] : $this->getContext($context, "exception")), "message", array()), "html", null, true);
        echo " (";
        echo twig_escape_filter($this->env, (isset($context["status_code"]) ? $context["status_code"] : $this->getContext($context, "status_code")), "html", null, true);
        echo " ";
        echo twig_escape_filter($this->env, (isset($context["status_text"]) ? $context["status_text"] : $this->getContext($context, "status_text")), "html", null, true);
        echo ")
";
        
        $__internal_c6b076fcf2fdbb67606871676ac36c06d5c272dacaa3acddfacea66aa1e45dda->leave($__internal_c6b076fcf2fdbb67606871676ac36c06d5c272dacaa3acddfacea66aa1e45dda_prof);

    }

    // line 11
    public function block_body($context, array $blocks = array())
    {
        $__internal_663203db67e765fe9b1a3603c8782bec09fb58978d0cf9e82c4340714b3a4d8c = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_663203db67e765fe9b1a3603c8782bec09fb58978d0cf9e82c4340714b3a4d8c->enter($__internal_663203db67e765fe9b1a3603c8782bec09fb58978d0cf9e82c4340714b3a4d8c_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 12
        echo "    ";
        $this->loadTemplate("@Twig/Exception/exception.html.twig", "@Twig/Exception/exception_full.html.twig", 12)->display($context);
        
        $__internal_663203db67e765fe9b1a3603c8782bec09fb58978d0cf9e82c4340714b3a4d8c->leave($__internal_663203db67e765fe9b1a3603c8782bec09fb58978d0cf9e82c4340714b3a4d8c_prof);

    }

    public function getTemplateName()
    {
        return "@Twig/Exception/exception_full.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  78 => 12,  72 => 11,  58 => 8,  52 => 7,  42 => 4,  36 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends '@Twig/layout.html.twig' %}

{% block head %}
    <link href=\"{{ absolute_url(asset('bundles/framework/css/exception.css')) }}\" rel=\"stylesheet\" type=\"text/css\" media=\"all\" />
{% endblock %}

{% block title %}
    {{ exception.message }} ({{ status_code }} {{ status_text }})
{% endblock %}

{% block body %}
    {% include '@Twig/Exception/exception.html.twig' %}
{% endblock %}
", "@Twig/Exception/exception_full.html.twig", "/var/www/html/openMindReader/vendor/symfony/symfony/src/Symfony/Bundle/TwigBundle/Resources/views/Exception/exception_full.html.twig");
    }
}
